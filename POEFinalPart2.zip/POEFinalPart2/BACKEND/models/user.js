const mongoose = require('mongoose')
const Joi = require('joi');

const userSchema = new mongoose.Schema(
    {
        
        username: {type: String, unique: true},
        firstName: {type: String},
        lastName: {type: String},
        password: {type: String},
        //phoneNumber: {type: String},
    }
)

const User = mongoose.model('User', userSchema)

function validateUser(user){
    const schema = Joi.object({
        username: Joi.string().min(3).max(50).required(),
        firstName: Joi.string().max(50).required(),
        lastName: Joi.string().max(50).required(),
        password: Joi.string().min(3).max(50).required(),
        //phoneNumber: Joi.string.min(12).max(12).required(),
    })
    return schema.validate(user);
}

module.exports = {User, validateUser};