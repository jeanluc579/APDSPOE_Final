const router = required('express').Router();
const jwt = require('jsonwebtoken');
const { User } = require('../models/user');
const {isValidPassword } = require ('..utils/hash');
//A brute force protection middleware for express routes that rate
const ExpressBrute = require('express-brute');
//in store memory for persisiting request counts
const store = new ExpressBrute.MemoryStore();
const bruteforce = new ExpressBrute(store);

//Login route
router.post('/', bruteforce.prevent, async (req, res) => {
    const user = await User.findOne({username: req.body.username});
    if (!user)
    return res.status(401).json({ error: 'incorrect username or password'})

    const valid = await isValidPassword(req.body.password, user.password)
})