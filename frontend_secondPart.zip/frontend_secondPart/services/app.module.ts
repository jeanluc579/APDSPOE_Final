import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.modules';
import { AppComponent } from './app.components';
import { NavbarComponent} from './common/navbar/navbar.component';
import { LoginComponent } from 'login/login.components';
import { SignupComponent } from 'signup/signup.components';
import { HomeComponent } from 'home/home.components';
import { ReactiveFormsModule } from '@angular/forms';
import {ErrorComponent } from './common/error/error.component';
import { HttpClientModule } from '@angular/common/http';
import { PostComponent } from './common/post/post/post.component';

@NgModule({
    declarations: [
        AppComponent,
        NavbarComponent,
        LoginComponent,
        SignupComponent,
        HomeComponent,
        ErrorComponent,
        PostComponent,
    ],
    imports: [
        BrowserModule,
        HttpClientModule,
        AppRoutingModule,
        ReactiveFormsModule,
    ],
    providers: [],
    bootstrap: [AppsComponent],
})
export class AppModule{}