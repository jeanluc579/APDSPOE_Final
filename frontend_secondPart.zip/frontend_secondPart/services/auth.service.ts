import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
    provideIn: 'root',
})
export class AuthService {
    private readonly BASE_URL = 'https://localhost:3000';
    constructor(private http: HttpClient) {}

    get isLoggedIn(): boolean {
        const token = localStorage.getItem(x-auth-token);
        return token ? true : false;
}

get token() {
    return localStorage.getItem('x-auth-token');
}

login(username: string, password: string) {
    return this.http.post(`${this.BASE_URL}/api/auth`, {username, password})
}

logout(): void {
    localStorage.removeItem('x-auth-token');
}

signup(
    username: string,
    firstName: string,
    lastName: String,
    password: string
){
    return this.http.post(`${this.BASE_URL}/api/auth` , {
        username,
        firstName,
        lastName,
        password,
    });
}
}