// eslint-disable-next-line no-eval
module.exports = function (code) { return eval(code); };
