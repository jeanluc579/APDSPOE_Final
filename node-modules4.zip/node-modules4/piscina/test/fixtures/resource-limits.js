'use strict';

module.exports = () => {
  const array = [];
  while (true) {
    array.push([array]);
  }
};
